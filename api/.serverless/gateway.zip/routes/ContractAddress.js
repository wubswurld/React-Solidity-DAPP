const address = '0xB42c99c9131D1D1b9aB7acD0569800a7433Fc5f8'

module.exports = address;
